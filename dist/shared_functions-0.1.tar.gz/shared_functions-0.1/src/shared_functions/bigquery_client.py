from google.cloud import bigquery

client = bigquery.Client(project='shabubsinc')